Functionality Covered:

1) Design and Development of Cab App using React
2) Unit Testing Done


Running Application:

1) goto C:\Users\47813\Desktop\cabapp-React-47813\cabApp-react  in terminal and run - npm start
2) for unit testing -  npm test