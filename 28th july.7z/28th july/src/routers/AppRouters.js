import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import LoginPage from './../Components/Login/Login.jsx';
import DriverSignup from './../Components/Signup/Driver/Driver.jsx';
import PassengerSignup from './../Components/Signup/Passenger/Passenger.jsx';
import PassengerDashboard from './../Components/Dashboard/PassengerDashboard/PassengerDashboard.jsx';
import DriverDashboard from './../Components/Dashboard/DriverDashboard/DriverDashboard.jsx';
import ToolBar from './../Components/Toolbar';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

const AppRouter = () => (
    <BrowserRouter>
        <MuiThemeProvider>
            <ToolBar />
            <Switch>
                <Route path="/" component={LoginPage} exact={true} />
                <Route path="/Login" component={LoginPage} />
                <Route path="/DriverSignup" component={DriverSignup} />
                <Route path="/PassengerSignup" component={PassengerSignup} />
                <Route path="/PassengerDashboard" component={PassengerDashboard} />
                <Route path="/DriverDashboard" component={DriverDashboard} />
            </Switch>
        </MuiThemeProvider>
    </BrowserRouter>
);

export default AppRouter;