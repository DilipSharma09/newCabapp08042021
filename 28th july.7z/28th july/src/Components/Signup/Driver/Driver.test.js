import React from 'react';
import renderer from 'react-test-renderer';

import Driver from './Driver';

const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    clear: jest.fn()
};
global.localStorage = localStorageMock;

it('Login Test', () => {
    const tree = renderer.create(<Driver/>).toJSON();
    expect(tree).toMatchSnapshot();
});