import React from 'react';
import renderer from 'react-test-renderer';

import Passenger from './Passenger';

const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    clear: jest.fn()
};
global.localStorage = localStorageMock;

it('Login Test', () => {
    const tree = renderer.create(<Passenger/>).toJSON();
    expect(tree).toMatchSnapshot();
});