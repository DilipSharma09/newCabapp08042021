import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
import { Form, Input, Button } from "antd";
import { Redirect } from 'react-router-dom'
import '../Driver/Driver.css'

const FormItem = Form.Item;

class PassengerSignup extends Component {
    state = {
        res: {},
        res_received: false
    };

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue
                };
                //delete values[""];
                console.log("Received values of form: ", values);
                axios
                    .post("http://13.233.219.169:8080/registration/api/passenger", {
                        "p_FIRST_NAME": values.firstname,
                        "p_LAST_NAME": values.lastname,
                        "p_USERNAME": values.username,
                        "p_PASSWORD": values.password,
                        "p_PHONE_NO": values.phoneno,
                        "p_SOURCE": values.source,
                        "p_STATUS": values.status
                    }
                    )
                    .then(response => {
                        console.log(response);
                        // localStorage.setItem('AuthToken', response.data.auth_token)
                        this.setState({ res: response.data });
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        // this.setState({ res: 'test' });
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const { getFieldDecorator } = this.props.form;
        let result = null;
        if (this.state.res_received) {
            alert('Sign Up Succesful!');
            console.log(this.state.res_recieved);
            return <Redirect to='/login' />
        }

        return (
            <div>
                <div className="driver-signup-title">
                    Sign Up
                </div>
                <div>
                    <Form style={{ maxWidth: '56%' ,marginLeft: '22%' }} onSubmit={this.handleSubmit} className="signup-form">
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("firstname", {
                                rules: [{ required: true, message: "Please input your First Name!" }]
                            })(<Input placeholder="First Name" />)}
                        </FormItem>
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("lastname", {
                                rules: [{ required: true, message: "Please input your Last Name!" }]
                            })(<Input placeholder="Last Name" />)}
                        </FormItem>
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("username", {
                                rules: [{ required: true, message: "Please input your User Name!" }]
                            })(<Input placeholder="User Name" />)}
                        </FormItem>
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("password", {
                                rules: [
                                    { required: true, message: "Please input your Password!" },
                                    { min: 8, message: "Minimum password length is 8 characters" }
                                ]
                            })(<Input type="password" placeholder="Password" />)}
                        </FormItem>
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("source", {
                                rules: [{ required: true, message: "Please input your Source!" }]
                            })(<Input placeholder="Source" />)}
                        </FormItem>
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("status", {
                                rules: [{ required: true, message: "Please input your Status!" }]
                            })(<Input placeholder="Status" />)}
                        </FormItem>
                        <FormItem className="ant-form-item-signup-driver">
                            {getFieldDecorator("phoneno", {
                                rules: [{ required: true, message: "Please input your Phone No!" }]
                            })(<Input placeholder="Phone No" />)}
                        </FormItem>
                        <FormItem style={{
                            paddingLeft: '38%',
                            marginTop: '9px'
                        }}>
                            <div style={{ display: 'flex' }}>
                                <Button
                                    type="primary"
                                    htmlType="submit"
                                    style={{
                                        background: 'green',
                                        border: 'none'
                                    }}
                                >
                                    Register
                            </Button>
                                <Button
                                    type="primary"
                                    href="/Login"
                                    style={{
                                        marginLeft: '8px',
                                        background: 'grey',
                                        border: 'none'
                                    }}
                                >
                                    cancel
                            </Button>
                            </div>
                        </FormItem>
                        {result}
                    </Form>

                </div>
            </div>
        );
    }
}

const Sign_up = Form.create()(PassengerSignup);

export default Sign_up;
