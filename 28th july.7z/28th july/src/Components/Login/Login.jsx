import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
import { Form, Input, Button } from "antd";
import { Redirect } from 'react-router-dom'
import './Login.css';

const styleText = {
    marginLeft: '100px',
    fontSize: '1.71429rem',
    fontFamily: 'ff-clan-web-pro,"Helvetica Neue",Helvetica,sans-serif!important',
    fontWeight: '400'
};

const FormItem = Form.Item;

class Login extends Component {
    state = {
        res: {},
        res_received: false,
        optionsState: 'driver'
    };

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue,
                };
                console.log("Received values of form: ", values);
                axios
                    .get(`http://13.233.219.169:8080/registration/api/${this.state.optionsState}/login?username=${values.username}&password=${values.password}`
                    )
                    .then(response => {
                        console.log(response);
                        localStorage.setItem('AuthToken', response.data.auth_token)
                        localStorage.setItem('userData', JSON.stringify(response.data));
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: wrong credentials entered!");
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const { getFieldDecorator } = this.props.form;
        if (this.state.res_received) {
            alert('Login Succesful!');
            console.log(this.state.res_recieved);
            if (this.state.optionsState == 'driver') {
                return <Redirect to='/DriverDashboard' />
            }
            return <Redirect to='/PassengerDashboard' />
        }
        const optionsState = this.state.optionsState;
        return (
            <div className="login">
                <div style={{
                    marginLeft: '0px', marginBottom: '40px',
                    borderBottom: '4px solid #f7f7f7'
                }}>
                    <div style={styleText}>
                        CAB APP
                        </div>
                </div>
                <div className="bookRideSectionLogin">
                    <div className="bookRideheaderLogin">
                        <div>
                            <span>Login</span>
                        </div>
                    </div>
                    <div className="bookRideBodyLogin">
                        <Form onSubmit={this.handleSubmit} className="signup-form">
                            <FormItem>
                                {getFieldDecorator("username", {
                                    rules: [{ required: true, message: "Please input your UserName!" }]
                                })(<label>User Name <Input className="ant-input-login" placeholder="User Name" /> </label>)}
                            </FormItem>
                            <FormItem>
                                {getFieldDecorator("password", {
                                    rules: [
                                        { required: true, message: "Please input your Password!" },
                                        { min: 8, message: "Minimum password length is 8 characters" }
                                    ]
                                })(<label>Password <Input style={{ left: '69px' }} className="ant-input-login" type="password" placeholder="Password" /></label>)}
                            </FormItem>
                            <FormItem>
                                <label>Login As <select style={{ left: '70px' }} className="ant-input-login"
                                    onChange={(value) => {
                                        this.setState({ optionsState: value.target.value })
                                    }} value={optionsState}>
                                    <option value="driver">Driver</option>
                                    <option value="passenger">Passenger</option>
                                </select></label>
                            </FormItem>
                            <FormItem style={{ marginLeft: '37%' }}>
                                <Button
                                    type="primary"
                                    htmlType="submit"
                                >
                                    LOGIN
                        </Button>
                            </FormItem>
                            <div style={{ display: 'flex' }}>
                                <Button
                                    type="primary"
                                    href="/DriverSignup"
                                >
                                    Driver Registration
                        </Button>
                                <Button style={{ marginLeft: '9px' }}
                                    type="primary"
                                    href="/PassengerSignup"
                                >
                                    Passenger Registration
                        </Button>
                            </div>
                        </Form>
                    </div>
                </div>
            </div >
        );
    }
}

const Sign_up = Form.create()(Login);

export default Sign_up;
