import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
import "./PassengerDashboard.css";
import Paper from 'material-ui/Paper';
import { Form, Input, Button } from "antd";

const stylePaper = {
    height: 'auto',
    width: '50%',
    // background: '#f8f8f9',
    position: 'relative',
    marginLeft: '25%',
    marginTop: '20px',
    padding: '20px 40px'
};

class PassengerDashboard extends Component {
    state = {
        res: {},
        passengerDetails: {},
        destination: 'AGS',
        price: 0,
        payment: 'card',
        destinationList: ['AGS', 'padur', 'navalur', 'sipcot'],
        routeDetails: {},
        tripDetails: {},
        tripStatus: 0,
        last5Trip: [],
        res_received: false
    };

    constructor() {
        super();
        this.onChangeDestination = this.onChangeDestination.bind(this);
        this.onChangeCash = this.onChangeCash.bind(this);
        this.bookRide = this.bookRide.bind(this);
        this.cancelTrip = this.cancelTrip.bind(this);
        // this.getTripDetails = this.getTripDetails.bind(this);
    }

    componentDidMount() {
        console.log(this.state.destination);
        this.getRoutePrice(this.state.destination);
        this.setState({ passengerDetails: JSON.parse(localStorage.getItem('userData')) });
        this.getTripDetails();
        this.getLast5Trip();
    }

    getLast5Trip() {
        const passengerDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/booking/api/trip/last_five_for_passenger/${passengerDetails.p_ID}`)
            .then(response => {
                console.log(response);
                const data = [{ 'id': 'colName', 1: 'Date', 2: 'Source', 3: 'Destination', 4: 'Status', 5: 'Payment' }];
                for (let i = 0; i < response.data.length; i++) {
                    const rowdata = response.data[i];
                    data.push(
                        {
                            'id': rowdata.t_ID, 1: rowdata.t_DATE, 2: rowdata.t_SOURCE, 3: rowdata.t_DESTINATION,
                            4: rowdata.t_STATUS, 5: rowdata.t_PAYMENT
                        }
                    );
                }
                this.setState({ last5Trip: data });
            });
    }

    getTripDetails() {
        const passengerDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/booking/api/trip/lastest_trip_passenger/${passengerDetails.p_ID}`)
            .then(response => {
                console.log(response);
                if (response.data) {
                    this.setState({ tripDetails: response.data });
                    this.setState({ tripStatus: response.data.t_STATUS });
                }
            });
    }

    getRoutePrice(destination) {
        const passengerDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/booking/api/route/getroute/${passengerDetails.p_SOURCE}/${destination}`)
            .then(response => {
                console.log(response);
                this.setState({ routeDetails: response.data });
                this.setState({ price: response.data.r_FARE });
            });
    }

    onChangeCash(event) {
        console.log(event.target.value);
        this.setState({ payment: event.target.value });
    }

    onChangeDestination(event) {
        console.log(event.target.value);
        this.setState({ destination: event.target.value });
        this.getRoutePrice(event.target.value);
    }

    refreshPassenger() {
        window.location.reload();
    }

    cancelTrip() {
        const passengerDetails = this.state.passengerDetails;
        const tripData = this.state.tripDetails;
        tripData.t_STATUS = 1;
        axios
            .put("http://13.233.219.169:8080/booking/api/trip", tripData
            )
            .then(response => {
                console.log(response);
                this.setState({ tripDetails: response.data });
                passengerDetails.p_STATUS = 0;
                axios
                    .put("http://13.233.219.169:8080/registration/api/passenger", passengerDetails)
                    .then(response => {
                        console.log('passeger', response);
                        localStorage.setItem('userData', JSON.stringify(response.data));
                        this.setState({ passengerDetails: response.data });
                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        // this.setState({ res: 'test' });
                        console.log(error);
                    });
            });
    }

    bookRide() {
        const passengerDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/registration/api/driver/count/${passengerDetails.p_SOURCE}`)
            .then(response => {
                console.log(response);
                if (response.data > 0) {
                    axios
                        .post("http://13.233.219.169:8080/booking/api/trip", {
                            "t_ID": 0,
                            "t_STATUS": 0,
                            "t_ROUTE_ID": this.state.routeDetails.r_ID,
                            "t_SOURCE": passengerDetails.p_SOURCE,
                            "t_DESTINATION": this.state.destination,
                            "t_DRIVER_ID": 0,
                            "t_PASSENGER_ID": passengerDetails.p_ID,
                            "t_DATE": new Date(),
                            "t_PAYMENT": this.state.payment
                        }
                        )
                        .then(response => {
                            console.log(response);
                            this.setState({ tripDetails: response.data });
                            passengerDetails.p_STATUS = 1;
                            axios
                                .put("http://13.233.219.169:8080/registration/api/passenger", passengerDetails)
                                .then(response => {
                                    console.log('passeger', response);
                                    localStorage.setItem('userData', JSON.stringify(response.data));
                                    this.setState({ passengerDetails: response.data });
                                })
                                .catch(error => {
                                    alert("ERROR: User name already exists!");
                                    // this.setState({ res: 'test' });
                                    console.log(error);
                                });
                        });
                } else {
                    alert("No Drivers available at this moment");
                }
                // if(response.data)
                // localStorage.setItem('AuthToken', response.data.auth_token)
                // this.setState({ res: response.data });
                // this.setState({ res_received: true });
            })
            .catch(error => {
                alert("ERROR: User name already exists!")
                console.log(error);
            });
    }

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue,
                    role: 'user'
                };
                //delete values[""];
                console.log("Received values of form: ", values);
                axios
                    .post("https://api.crossfire37.hasura-app.io/signup", {
                        "user": {
                            "provider": "username",
                            "data": {
                                "username": values.firstname,
                                "password": values.password
                            }
                        },
                        "role": values.role,
                        "firstname": values.firstname,
                        "lastname": values.lastname
                    }
                    )
                    .then(response => {
                        console.log(response);
                        //                         const userData = localStorage.getItem('userData');
                        // console.log('retrievedObject: ', JSON.parse(retrievedObject));
                        localStorage.setItem('AuthToken', response.data.auth_token)
                        this.setState({ res: response.data });
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        this.setState({ res: 'test' });
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const passengerDetails = this.state.passengerDetails;
        let destinationSelect = this.state.destinationList;
        destinationSelect = destinationSelect.filter(a => a != passengerDetails.p_SOURCE);

        const { getFieldDecorator } = this.props.form;
        let result = null;
        if (true) {
            //  alert('Sign Up Succesful! Please go to "Ride" to book your ride.');
            console.log(this.state.res_recieved);
        }

        let tableStyle = {
            align: "center"
        };

        let list = this.state.last5Trip.map(p => {
            return (
                <tr className="grey2 border-top" key={p.id}>
                    {Object.keys(p).filter(k => k !== 'id').map(k => {
                        return (
                            <td className="grey1" key={p.id + '' + k}>
                                <div suppressContentEditableWarning="true" contentEditable="true" value={k} >
                                    {p[k]}
                                </div>
                            </td>
                        );
                    })}
                </tr>
            );
        });


        return (
            <div>
                <h2 className="pageheader">Passenger Dashboard</h2>
                <Paper style={stylePaper}>
                    {passengerDetails && passengerDetails.p_STATUS == 0 &&
                        <div className="bookRideSection bookRideheaderSectionOne">
                            <div className="bookRideheader ">
                                <span>Book a ride</span>
                            </div>
                            <div className="bookRideBody">
                                <div className="bookRideBodyData">
                                    <label>Destination:
                                    <select onChange={this.onChangeDestination}>
                                            {destinationSelect.map((dest, index) => {
                                                return <option>{dest}</option>;
                                            })}
                                        </select>
                                    </label>
                                </div>
                                <div className="bookRideBodyData">
                                    <label>Fare: {this.state.price} </label>
                                </div>
                                <div className="bookRideBodyData">
                                    <select onChange={this.onChangeCash}>
                                        <option value="Card">Card</option>
                                        <option value="paytm">paytm</option>
                                        <option value="cash">Cash</option>
                                    </select>
                                </div>
                                <div className="bookRideBodyData">
                                    <Button
                                        type="primary"
                                        onClick={this.bookRide}
                                    >
                                        Book a Ride
                                </Button>
                                </div>
                            </div>
                        </div>
                    }
                    {passengerDetails && passengerDetails.p_STATUS == 1 &&
                        <div className="bookRideSection bookRideheaderSectionOne">
                            <div className="rideAcceptHeader ">
                                <h3 className="rideAcceptHeaderText">Waiting for driver to accept ride</h3>
                            </div>
                            <div className="rideAcceptBody">
                                <div className="">
                                    <Button
                                        type="primary"
                                        onClick={this.refreshPassenger}
                                    >
                                        Refresh
                                </Button>
                                </div>
                                <div className="">
                                    <Button
                                        type="primary"
                                        onClick={this.cancelTrip}
                                    >
                                        Cancel
                                </Button>
                                </div>
                            </div>
                        </div>
                    }
                    {this.state.tripStatus == 2 &&
                        <div className="bookRideSection bookRideheaderSectionOne">
                            <div className="bookRideheader ">
                                <span>Enroute to Destination</span>
                            </div>
                            <div className="enRouteBody">
                                <div className="enrouteBodyData">
                                    <label>DriverName: driver</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <label>Fare: 200 </label>
                                </div>
                                <div className="enrouteBodyData">
                                    <Button
                                        type="primary"
                                    >
                                        Refresh
                                </Button>
                                </div>
                            </div>
                            <div className="enRouteBodyTwo">
                                <div className="enrouteBodyData">
                                    <label>Phone: 9857903455</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <label>CanRegNo: 3356ugv </label>
                                </div>
                            </div>
                        </div>
                    }
                    <div className="bookRideSection">
                        <div className="bookRideheader">
                            <span>Last 5 Trip</span>
                        </div>
                        <div className="bookRideBody">
                            <fieldset className="step-4">
                                <div className="schedule padd-lr">
                                    <table cellSpacing="15" id="mytable" style={tableStyle}>
                                        <tbody>{list}</tbody>
                                    </table>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                </Paper>
            </div>
        );
    }
}

const Sign_up = Form.create()(PassengerDashboard);

export default Sign_up;
