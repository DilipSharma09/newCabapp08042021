import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
import "./DriverDashboard.css";
import Paper from 'material-ui/Paper';
import { Form, Input, Button } from "antd";

const stylePaper = {
    height: 'auto',
    width: '50%',
    position: 'relative',
    marginLeft: '25%',
    marginTop: '20px',
    padding: '20px 40px'
};

class DriverDashboard extends Component {
    state = {
        driverDetails: {},
        tripsAvailableData: [],
        tripDetails: {},
        passengerDetails: {},
        last5Trip: [],
        res: {},
        res_received: false
    };


    constructor() {
        super();
        this.acceptRide = this.acceptRide.bind(this);
        this.startTrip = this.startTrip.bind(this);
        this.cancelTrip = this.cancelTrip.bind(this);
        this.endTrip = this.endTrip.bind(this);
        this.newTrip = this.newTrip.bind(this);
    }

    componentDidMount() {
        this.setState({ driverDetails: JSON.parse(localStorage.getItem('userData')) });
        this.getAvailableTrips();
        this.getTripDetails();
        this.getLast5Trip();
    }

    getAvailableTrips() {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/booking/api/trip/available_trips/${driverDetails.d_SOURCE}`)
            .then(response => {
                console.log(response);
                const data = [{ 'id': 'colName', 1: 'Passenger_ID', 2: 'Source', 3: 'Destination', 4: '' }];
                for (let i = 0; i < response.data.length; i++) {
                    const rowdata = response.data[i];
                    data.push(
                        {
                            'id': rowdata.t_ID, 1: rowdata.t_PASSENGER_ID, 2: rowdata.t_SOURCE, 3: rowdata.t_DESTINATION, 4: ''
                        }
                    );
                }
                this.setState({ tripsAvailableData: data });
            });
    }

    getLast5Trip() {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/booking/api/trip/last_five_for_driver/${driverDetails.d_ID}`)
            .then(response => {
                console.log(response);
                const data = [{ 'id': 'colName', 1: 'Date', 2: 'Source', 3: 'Destination', 4: 'Status', 5: 'Payment' }];
                for (let i = 0; i < response.data.length; i++) {
                    const rowdata = response.data[i];
                    data.push(
                        {
                            'id': rowdata.t_ID, 1: rowdata.t_DATE, 2: rowdata.t_SOURCE, 3: rowdata.t_DESTINATION,
                            4: rowdata.t_STATUS, 5: rowdata.t_PAYMENT
                        }
                    );
                }
                this.setState({ last5Trip: data });
            });
    }

    getTripDetails() {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            // .get(`http://13.233.219.169:8080/booking/api/trip/lastest_trip_driver/${driverDetails.d_ID}`)
            .get(`http://13.233.219.169:8080/booking/api/trip`)
            .then(response => {
                console.log(response);
                if (response.data && response.data.length > 0) {
                    const driverTrip = response.data.filter(a => a.t_DRIVER_ID == driverDetails.d_ID);
                    const tripDetails = driverTrip[driverTrip.length - 1];
                    if (tripDetails) {
                        this.setState({ tripDetails: tripDetails });
                        console.log('tripDetails', tripDetails);
                        axios
                            .get(`http://13.233.219.169:8080/registration/api/passenger/${tripDetails.t_PASSENGER_ID}`)
                            .then(response => {
                                this.setState({ passengerDetails: response.data });
                            });
                    }
                }
            });
    }


    acceptRide(tripId) {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        axios
            .get(`http://13.233.219.169:8080/booking/api/trip/${tripId}`)
            .then(response => {
                const tripDetails = response.data;
                console.log(tripDetails);
                tripDetails.t_STATUS = 2;
                tripDetails.t_DRIVER_ID = driverDetails.d_ID;
                axios
                    .get(`http://13.233.219.169:8080/registration/api/passenger/${tripDetails.t_PASSENGER_ID}`)
                    .then(response => {
                        this.setState({ passengerDetails: response.data });
                        axios
                            .put("http://13.233.219.169:8080/booking/api/trip", tripDetails
                            )
                            .then(response => {
                                this.setState({ tripDetails: response.data });
                                driverDetails.d_STATUS = 1;
                                axios
                                    .put("http://13.233.219.169:8080/registration/api/driver", driverDetails)
                                    .then(response => {
                                        console.log('passeger', response);
                                        localStorage.setItem('userData', JSON.stringify(response.data));
                                        this.setState({ driverDetails: response.data });
                                        this.getLast5Trip();
                                    })
                                    .catch(error => {
                                        alert("ERROR: User name already exists!");
                                        // this.setState({ res: 'test' });
                                        console.log(error);
                                    });
                            });

                    });
            });
    }

    startTrip() {
        const tripDetails = this.state.tripDetails;
        tripDetails.t_STATUS = 3;
        axios
            .put("http://13.233.219.169:8080/booking/api/trip", tripDetails
            )
            .then(response => {
                this.setState({ tripDetails: response.data });
                this.getLast5Trip();
            });

    }

    cancelTrip() {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        const tripDetails = this.state.tripDetails;
        tripDetails.t_STATUS = 4;
        axios
            .put("http://13.233.219.169:8080/booking/api/trip", tripDetails
            )
            .then(response => {
                driverDetails.d_STATUS = 0;
                axios
                    .put("http://13.233.219.169:8080/registration/api/driver", driverDetails)
                    .then(response => {
                        console.log('passeger', response);
                        localStorage.setItem('userData', JSON.stringify(response.data));
                        this.setState({ driverDetails: response.data });
                        axios
                            .get(`http://13.233.219.169:8080/registration/api/passenger/${tripDetails.t_PASSENGER_ID}`)
                            .then(response => {
                                const passengerDetails = response.data;
                                passengerDetails.p_STATUS = 0;
                                axios
                                    .put("http://13.233.219.169:8080/registration/api/passenger", passengerDetails)
                                    .then(response => {
                                        this.setState({ passengerDetails: response.data });
                                        this.getLast5Trip();
                                    })
                                    .catch(error => {
                                        alert("ERROR: User name already exists!");
                                        // this.setState({ res: 'test' });
                                        console.log(error);
                                    });
                            })
                            .catch(error => {
                                alert("ERROR: User name already exists!");
                                // this.setState({ res: 'test' });
                                console.log(error);
                            });

                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        // this.setState({ res: 'test' });
                        console.log(error);
                    });
            });
    }

    endTrip() {
        const tripDetails = this.state.tripDetails;
        tripDetails.t_STATUS = 5;
        axios
            .put("http://13.233.219.169:8080/booking/api/trip", tripDetails
            )
            .then(response => {
                this.setState({ tripDetails: response.data });
                this.getLast5Trip();
            });
    }

    newTrip() {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        const tripDetails = this.state.tripDetails;
        tripDetails.t_STATUS = 6;
        axios
            .put("http://13.233.219.169:8080/booking/api/trip", tripDetails
            )
            .then(response => {
                this.setState({ tripDetails: response.data });
                driverDetails.d_STATUS = 0;
                axios
                    .put("http://13.233.219.169:8080/registration/api/driver", driverDetails)
                    .then(response => {
                        console.log('passeger', response);
                        localStorage.setItem('userData', JSON.stringify(response.data));
                        this.setState({ driverDetails: response.data });
                        axios
                            .get(`http://13.233.219.169:8080/registration/api/passenger/${tripDetails.t_PASSENGER_ID}`)
                            .then(response => {
                                const passengerDetails = response.data;
                                passengerDetails.p_STATUS = 0;
                                axios
                                    .put("http://13.233.219.169:8080/registration/api/passenger", passengerDetails)
                                    .then(response => {
                                        this.setState({ passengerDetails: response.data });
                                        this.getLast5Trip();
                                    })
                                    .catch(error => {
                                        alert("ERROR: User name already exists!");
                                        // this.setState({ res: 'test' });
                                        console.log(error);
                                    });
                            })
                            .catch(error => {
                                alert("ERROR: User name already exists!");
                                // this.setState({ res: 'test' });
                                console.log(error);
                            });

                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        // this.setState({ res: 'test' });
                        console.log(error);
                    });
            });
    }

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue,
                    role: 'user'
                };
                //delete values[""];
                console.log("Received values of form: ", values);
                axios
                    .post("https://api.crossfire37.hasura-app.io/signup", {
                        "user": {
                            "provider": "username",
                            "data": {
                                "username": values.firstname,
                                "password": values.password
                            }
                        },
                        "role": values.role,
                        "firstname": values.firstname,
                        "lastname": values.lastname
                    }
                    )
                    .then(response => {
                        console.log(response);
                        localStorage.setItem('AuthToken', response.data.auth_token)
                        this.setState({ res: response.data });
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        this.setState({ res: 'test' });
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const driverDetails = JSON.parse(localStorage.getItem('userData'));
        const { getFieldDecorator } = this.props.form;
        let result = null;
        if (true) {
            //  alert('Sign Up Succesful! Please go to "Ride" to book your ride.');
            console.log(this.state.res_recieved);
        }

        let tableStyle = {
            align: "center"
        };

        let list = this.state.last5Trip.map(p => {
            return (
                <tr className="grey2 border-top" key={p.id}>
                    {Object.keys(p).filter(k => k !== 'id').map(k => {
                        return (
                            <td className="grey1" key={p.id + '' + k}>
                                <div suppressContentEditableWarning="true" contentEditable="true" value={k} >
                                    {p[k]}
                                </div>
                            </td>
                        );
                    })}
                </tr>
            );
        });

        let tripsAvailable = this.state.tripsAvailableData.map(p => {
            return (
                <tr className="grey2 border-top" key={p.id}>
                    {Object.keys(p).filter(k => k !== 'id').map(k => {
                        let t;
                        if (p[1] != "Passenger_ID" && k == 4) {
                            t = <button onClick={() => this.acceptRide(p.id)} >Accept</button>
                        } else {
                            t = <div suppressContentEditableWarning="true" contentEditable="true" value={k} >
                                {p[k]}
                            </div>
                        }
                        return (
                            <td className="grey1" key={p.id + '' + k}>
                                {t}
                            </td>
                        );
                    })
                    }
                </tr>
            );
        });


        return (
            <div>
                <h2 className="pageheader">Driver Dashboard</h2>
                <Paper style={stylePaper}>
                    {driverDetails && driverDetails.d_STATUS == 0 &&
                        <div className="bookRideSection">
                            <div className="bookRideheader">
                                <span>Trips Available</span>
                            </div>
                            <div className="bookRideBody">
                                <fieldset className="step-4">
                                    <div className="schedule padd-lr">
                                        <table cellSpacing="15" id="mytable" style={tableStyle}>
                                            <tbody>{tripsAvailable}</tbody>
                                        </table>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                    }
                    {driverDetails && driverDetails.d_STATUS == 1 && this.state.tripDetails && this.state.tripDetails.t_STATUS == 2 &&
                        <div className="bookRideSection bookRideheaderSectionOne">
                            <div className="bookRideheader ">
                                <span>Enroute to Passeneger</span>
                            </div>
                            <div className="enRouteBody">
                                <div className="enrouteBodyData">
                                    <label>Passeneger: {`${this.state.passengerDetails.p_FIRST_NAME} ${this.state.passengerDetails.p_LAST_NAME}`}</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <label>Destination: {this.state.tripDetails.t_DESTINATION} </label>
                                </div>
                                <div className="enrouteBodyData">
                                    <Button
                                        type="primary"
                                        onClick={this.startTrip}
                                    >
                                        Start
                                </Button>
                                </div>
                            </div>
                            <div className="enRouteBodyTwo">
                                <div className="enrouteBodyData">
                                    <label>Phone: {this.state.passengerDetails.p_PHONE_NO}</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <Button
                                        type="primary"
                                        onClick={this.cancelTrip}
                                    >
                                        Cancel
                                </Button>
                                </div>
                            </div>
                        </div>
                    }
                    {this.state.tripDetails && this.state.tripDetails.t_STATUS == 3 &&
                        <div className="bookRideSection bookRideheaderSectionOne">
                            <div className="bookRideheader ">
                                <span>Enroute to Destiination</span>
                            </div>
                            <div className="enRouteBody">
                                <div className="enrouteBodyData">
                                    <label>Passeneger: {`${this.state.passengerDetails.p_FIRST_NAME} ${this.state.passengerDetails.p_LAST_NAME}`}</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <label>Destination:  {this.state.tripDetails.t_DESTINATION}  </label>
                                </div>
                                <div className="enrouteBodyData">
                                    <Button
                                        type="primary"
                                        onClick={this.endTrip}
                                    >
                                        End Trip
                                </Button>
                                </div>
                            </div>
                            <div className="enRouteBodyTwo">
                                <div className="enrouteBodyData">
                                    <label>Phone:  {this.state.passengerDetails.p_PHONE_NO}</label>
                                </div>
                            </div>
                        </div>
                    }
                    {this.state.tripDetails && this.state.tripDetails.t_STATUS == 5 &&
                        <div className="bookRideSection bookRideheaderSectionOne">
                            <div className="bookRideheader ">
                                <span> Destiination Reached</span>
                            </div>
                            <div className="enRouteBody">
                                <div className="enrouteBodyData">
                                    <label>Passeneger: Passeneger</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <label>Destination: padur </label>
                                </div>
                                <div className="enrouteBodyData">
                                    <Button
                                        type="primary"
                                        onClick={this.newTrip}
                                    >
                                        New Trip
                                    </Button>
                                </div>
                            </div>
                            <div className="enRouteBodyTwo">
                                <div className="enrouteBodyData">
                                    <label>Phone: 9857903455</label>
                                </div>
                                <div className="enrouteBodyData">
                                    <label>Fare: 200</label>
                                </div>
                            </div>
                        </div>
                    }
                    <div className="bookRideSection">
                        <div className="bookRideheader">
                            <span>Last 5 Trip</span>
                        </div>
                        <div className="bookRideBody">
                            <fieldset className="step-4">
                                <div className="schedule padd-lr">
                                    <table cellSpacing="15" id="mytable" style={tableStyle}>
                                        <tbody>{list}</tbody>
                                    </table>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                </Paper>
            </div>
        );
    }
}

const Sign_up = Form.create()(DriverDashboard);

export default Sign_up;
