import React from 'react';

const HelpPage = () => (
    <div>
        Help
    </div>
);

export default HelpPage;
