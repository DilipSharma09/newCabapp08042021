import React from 'react';
import { Toolbar, ToolbarGroup } from 'material-ui/Toolbar';
import { Form, Input, Button } from "antd";

const styleDiv = {
  padding: '0px 127px',
};

const styleToolbar = {
  background: 'white',
  padding: '0px',
};

const styleUber = {
  margin: '0px',
};

const styleTabs = {
  marginLeft: '28px',
  background: 'white',
};

const StyleTab = {
  TabLeft: {
    padding: '0px 20px',
    borderTop: '4px',
    background: 'white',
    color: 'black',
    textTransform: 'capitalize',
  },
  TabRight: {
    padding: '0px',
    margin: '0px',
    borderTop: '4px',
    background: 'white',
    color: 'black',
  },
};

const styleInkBar = {
  background: 'white',
};

export default class ToolbarExamplesSimple extends React.Component {

  render() {
    const location = window.location.pathname.toLowerCase();
    if (location == '/login' || location == "/" || location == "/driversignup" || location == "/passengersignup") {
      return null;
    }
    return (
      <div style={styleDiv}>
        <Toolbar style={styleToolbar}>
          <ToolbarGroup>
            <label>CAB APP</label>
          </ToolbarGroup>
          <ToolbarGroup>
            <Button href='/'>Logout</Button>
          </ToolbarGroup>
        </Toolbar>
      </div>
    );
  }
}
